"""
staff_ui.py — Staff / Admin dashboard.
Each staff account is locked to their assigned hospital.
Beds are displayed as a clean color-coded block grid.
"""

import streamlit as st
import math
from config import (
    STAFF_CREDS, HOSPITALS, COMPLAINTS,
    get_queue, next_token, timestamp, bed_status_color,
)


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────
def _my_hospital() -> str:
    return st.session_state.staff_hospital

def _my_name() -> str:
    return STAFF_CREDS[st.session_state.staff_username]["name"]


# ─────────────────────────────────────────────────────────────
# BED GRID — the star feature
# ─────────────────────────────────────────────────────────────
def _bed_grid(hospital: str):
    """
    Renders beds as small colored blocks.
    Green  = available
    Red    = occupied
    Blue   = emergency / ICU (simulated as first 2 beds)
    """
    beds    = st.session_state.beds[hospital]
    total   = beds["total"]
    avail   = beds["available"]
    occupied = total - avail

    # Legend
    st.markdown("""
    <div style="display:flex;gap:18px;align-items:center;margin-bottom:18px;flex-wrap:wrap;">
        <div style="display:flex;align-items:center;gap:6px;">
            <div style="width:14px;height:14px;background:#22c55e;border-radius:4px;"></div>
            <span style="font-size:12px;color:#64748b;font-weight:500;">Available</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
            <div style="width:14px;height:14px;background:#ef4444;border-radius:4px;"></div>
            <span style="font-size:12px;color:#64748b;font-weight:500;">Occupied</span>
        </div>
        <div style="display:flex;align-items:center;gap:6px;">
            <div style="width:14px;height:14px;background:#6366f1;border-radius:4px;"></div>
            <span style="font-size:12px;color:#64748b;font-weight:500;">ICU / Emergency</span>
        </div>
    </div>""", unsafe_allow_html=True)

    # Build block HTML
    blocks_per_row = 10
    icu_beds       = min(2, total)   # first 2 beds are ICU (always)
    blocks_html    = '<div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:8px;">'

    for bed_num in range(1, total + 1):
        is_icu      = bed_num <= icu_beds
        is_occupied = bed_num <= occupied

        if is_icu:
            bg    = "#6366f1"
            border= "#4f46e5"
            label_color = "white"
        elif is_occupied:
            bg    = "#ef4444"
            border= "#dc2626"
            label_color = "white"
        else:
            bg    = "#22c55e"
            border= "#16a34a"
            label_color = "white"

        title = f"Bed {bed_num} — {'ICU' if is_icu else 'Occupied' if is_occupied else 'Available'}"
        blocks_html += f"""
        <div title="{title}" style="
            width:36px; height:36px;
            background:{bg}; border:2px solid {border};
            border-radius:6px;
            display:flex; align-items:center; justify-content:center;
            font-size:10px; font-weight:700; color:{label_color};
            cursor:default; transition:transform .12s;
            box-shadow: 0 1px 4px rgba(0,0,0,0.12);
        ">{bed_num}</div>"""

        if bed_num % blocks_per_row == 0 and bed_num < total:
            blocks_html += '</div><div style="display:flex;flex-wrap:wrap;gap:6px;margin-bottom:6px;">'

    blocks_html += "</div>"

    st.markdown(blocks_html, unsafe_allow_html=True)

    # Summary bar
    pct_occ = int(occupied / total * 100) if total else 0
    occ_color = bed_status_color(hospital)
    st.markdown(f"""
    <div style="margin-top:12px;">
        <div style="display:flex;justify-content:space-between;font-size:12px;color:#64748b;margin-bottom:5px;">
            <span>Occupancy</span>
            <span style="font-weight:600;color:{occ_color};">{pct_occ}% occupied · {occupied}/{total} beds used</span>
        </div>
        <div style="height:8px;background:#e2e8f0;border-radius:999px;overflow:hidden;">
            <div style="width:{pct_occ}%;height:8px;background:{occ_color};border-radius:999px;transition:width .3s;"></div>
        </div>
    </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# TAB 1 — BED MANAGEMENT
# ─────────────────────────────────────────────────────────────
def _tab_beds(hospital: str):
    beds   = st.session_state.beds[hospital]
    avail  = beds["available"]
    total  = beds["total"]
    occupied = total - avail
    queue  = get_queue(hospital)

    # Top stat cards
    c1, c2, c3, c4 = st.columns(4)
    for col, label, val, color in [
        (c1, "Total Beds",    total,           "#6366f1"),
        (c2, "Available",     avail,           bed_status_color(hospital)),
        (c3, "Occupied",      occupied,        "#ef4444"),
        (c4, "In Queue",      len(queue),      "#d97706"),
    ]:
        with col:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-num" style="color:{color};">{val}</div>
                <div class="stat-label">{label}</div>
            </div>""", unsafe_allow_html=True)

    # Alerts
    st.markdown("<div style='height:16px'></div>", unsafe_allow_html=True)
    if avail == 0:
        st.error("🚨 **No beds available!** Emergency admissions only. New queue patients cannot be admitted.")
    elif avail <= 3:
        st.warning(f"⚠️ **Critical:** Only {avail} bed(s) remaining. Consider discharge or transfers.")

    st.markdown("---")
    st.markdown("#### 🛏️ Bed Map")
    _bed_grid(hospital)

    st.markdown("---")
    # Bed controls
    st.markdown("#### ⚙️ Bed Controls")
    bc1, bc2, bc3 = st.columns(3)
    with bc1:
        if st.button("➕ Add a Bed", use_container_width=True):
            st.session_state.beds[hospital]["total"]     += 1
            st.session_state.beds[hospital]["available"] += 1
            st.toast("Bed added successfully.", icon="✅")
            st.rerun()
    with bc2:
        if avail > 0:
            if st.button("➖ Remove a Bed", use_container_width=True):
                st.session_state.beds[hospital]["total"]     -= 1
                st.session_state.beds[hospital]["available"] -= 1
                st.toast("Bed removed.", icon="ℹ️")
                st.rerun()
        else:
            st.button("➖ Remove a Bed", use_container_width=True, disabled=True)

    with bc3:
        admitted_here = [p for p in st.session_state.patients
                         if p["hospital"] == hospital and p["status"] == "admitted"
                         and "[EMERGENCY]" not in p.get("complaint","")]
        if admitted_here:
            if st.button(f"🏠 Discharge Patient", use_container_width=True):
                admitted_here[0]["status"] = "done"
                st.session_state.beds[hospital]["available"] += 1
                st.toast(f"Discharged {admitted_here[0]['name']}", icon="🏠")
                st.rerun()
        else:
            st.button("🏠 Discharge Patient", use_container_width=True, disabled=True)

    st.markdown("---")
    # Admit from queue
    st.markdown("#### 🧾 Admit from Queue")
    if not queue:
        st.info("No patients waiting in queue at this hospital.")
    elif avail == 0:
        st.error("Cannot admit — no beds available.")
    else:
        options = {
            f"#{p['token']} · {p['name']} ({p['complaint']}) · Reg. {p.get('registered_at','—')}": p
            for p in queue
        }
        sel = st.selectbox("Select patient to admit", list(options.keys()), key="adm_from_q")
        if st.button("✅ Admit Selected", type="primary", use_container_width=True):
            chosen = options[sel]
            for p in st.session_state.patients:
                if p["token"] == chosen["token"]:
                    p["status"]      = "admitted"
                    p["admitted_at"] = timestamp()
                    break
            st.session_state.beds[hospital]["available"] -= 1
            st.success(f"✅ {chosen['name']} admitted. Bed allocated.")
            st.rerun()


# ─────────────────────────────────────────────────────────────
# TAB 2 — EMERGENCY ADMIT
# ─────────────────────────────────────────────────────────────
def _tab_emergency(hospital: str):
    beds  = st.session_state.beds[hospital]
    avail = beds["available"]

    st.markdown(f"""
    <div class="em-alert">
        🚨 EMERGENCY ADMISSION — Bypasses queue entirely.
        Only use for life-threatening / critical situations at <strong>{hospital}</strong>.
    </div>""", unsafe_allow_html=True)

    if avail == 0:
        st.error("🚨 No beds available at this hospital. Cannot proceed with emergency admission.")
        st.info("Options: Discharge a patient (Bed Management tab) or contact nearby hospitals.")

    with st.form("em_form", clear_on_submit=True):
        c1, c2 = st.columns(2)
        with c1:
            em_name  = st.text_input("Patient Name *", placeholder="Full name or 'Unknown'")
            em_phone = st.text_input("Mobile (if available)", placeholder="10-digit", max_chars=10)
        with c2:
            em_age      = st.number_input("Age (approx)", 0, 120, 35)
            em_gender   = st.selectbox("Gender", ["Unknown", "Male", "Female", "Other"])

        em_severity = st.select_slider(
            "Severity Level",
            options=["Moderate", "Serious", "Critical", "Life-threatening"],
            value="Critical",
        )
        em_complaint = st.text_area(
            "Emergency Description *",
            placeholder="e.g. Cardiac arrest, severe head trauma, unconscious, severe bleeding…",
            height=90,
        )

        col_sub = st.columns([1, 2])[1]
        submit = st.form_submit_button(
            "🚨 Admit Immediately",
            type="primary",
            use_container_width=True,
            disabled=(avail == 0),
        )

    if submit:
        if not em_name.strip():
            st.error("Patient name is required (use 'Unknown' if name unavailable).")
        elif not em_complaint.strip():
            st.error("Emergency description is required.")
        else:
            token = next_token()
            patient = {
                "id":            len(st.session_state.patients) + 1,
                "name":          em_name.strip(),
                "phone":         em_phone or "N/A",
                "age":           em_age,
                "gender":        em_gender,
                "complaint":     f"[EMERGENCY] {em_complaint.strip()}",
                "notes":         f"Severity: {em_severity}",
                "token":         token,
                "status":        "admitted",
                "hospital":      hospital,
                "registered_at": timestamp(),
                "is_emergency":  True,
            }
            st.session_state.patients.append(patient)
            st.session_state.beds[hospital]["available"] -= 1
            st.success(f"🚨 Emergency admission complete — Token #{token} · Bed allocated at {hospital}")
            st.rerun()

    # Active emergency patients
    emergencies = [p for p in st.session_state.patients
                   if p.get("is_emergency") and p["hospital"] == hospital and p["status"] == "admitted"]
    if emergencies:
        st.markdown("<br>**Active Emergency Patients:**")
        for p in emergencies:
            severity = p.get("notes", "")
            sev_color = "#dc2626" if "Life" in severity else ("#ea580c" if "Critical" in severity else "#d97706")
            st.markdown(f"""
            <div style="background:#fff1f2;border:1px solid #fecaca;border-radius:10px;
                        padding:14px 18px;margin-bottom:8px;">
                <div style="display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:6px;">
                    <div>
                        <span style="font-weight:700;color:#dc2626;font-size:15px;">🚨 {p['name']}</span>
                        <span style="font-size:12px;color:#94a3b8;margin-left:10px;">Token #{p['token']}</span>
                    </div>
                    <span style="background:{sev_color}22;color:{sev_color};
                                 padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;">
                        {severity}
                    </span>
                </div>
                <div style="font-size:13px;color:#7f1d1d;margin-top:6px;">{p['complaint'].replace('[EMERGENCY] ','')}</div>
                <div style="font-size:11px;color:#94a3b8;margin-top:4px;">
                    Admitted {p.get('registered_at','—')} &nbsp;·&nbsp; 📞 {p['phone']}
                </div>
            </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# TAB 3 — ALL PATIENTS (hospital-locked)
# ─────────────────────────────────────────────────────────────
def _tab_patients(hospital: str):
    st.markdown(f"Showing all patient records for **{hospital}**.")
    st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)

    # Filters
    fc1, fc2 = st.columns(2)
    with fc1:
        status_filter = st.multiselect(
            "Filter by Status",
            ["waiting", "admitted", "done"],
            default=["waiting", "admitted", "done"],
        )
    with fc2:
        search = st.text_input("🔍 Search by name or token", placeholder="e.g. Rahul or 1002")

    all_here = [
        p for p in st.session_state.patients
        if p["hospital"] == hospital and p["status"] in status_filter
        and (
            search.lower() in p["name"].lower()
            or search in str(p["token"])
            or not search.strip()
        )
    ]

    if not all_here:
        st.info("No records match the current filters.")
        return

    st.markdown(f"**{len(all_here)} record(s) found**")
    st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)

    status_meta = {
        "waiting":  ("#fef3c7", "#d97706", "⏳"),
        "admitted": ("#dbeafe", "#1d4ed8", "🏥"),
        "done":     ("#dcfce7", "#16a34a", "✅"),
    }

    for p in all_here:
        bg, fc, icon = status_meta.get(p["status"], ("#f8fafc","#64748b","•"))
        em_tag = " 🚨" if p.get("is_emergency") else ""
        st.markdown(f"""
        <div style="background:{bg};border:1px solid {fc}33;border-radius:12px;
                    padding:14px 18px;margin-bottom:8px;">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:6px;">
                <div>
                    <span style="font-weight:700;color:#0f172a;font-size:15px;">{icon}{em_tag} {p['name']}</span>
                    <span style="font-size:12px;color:#94a3b8;margin-left:8px;">Token #{p['token']}</span>
                    <span style="font-size:12px;color:#94a3b8;margin-left:8px;">📞 {p['phone']}</span>
                </div>
                <span style="background:{fc}22;color:{fc};padding:2px 10px;border-radius:999px;
                             font-size:11px;font-weight:700;text-transform:uppercase;">{p['status']}</span>
            </div>
            <div style="font-size:13px;color:#64748b;margin-top:8px;display:flex;gap:16px;flex-wrap:wrap;">
                <span>🩺 {p['complaint']}</span>
                <span>👤 {p.get('age','?')}y · {p.get('gender','—')}</span>
                <span>⏰ Reg. {p.get('registered_at','—')}</span>
                {f'<span>🏥 Admitted {p.get("admitted_at","—")}</span>' if p.get("admitted_at") else ""}
            </div>
            {f'<div style="font-size:12px;color:#94a3b8;margin-top:4px;font-style:italic;">📋 {p["notes"]}</div>' if p.get("notes") else ""}
        </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# MAIN RENDER
# ─────────────────────────────────────────────────────────────
def render():
    # ── Auth gate ──
    if not st.session_state.staff_logged_in:
        st.markdown("""
        <div style="text-align:center;padding:80px 20px;">
            <div style="font-size:60px;margin-bottom:16px;">🔐</div>
            <div style="font-size:22px;font-weight:700;color:#0f172a;margin-bottom:8px;">Staff Login Required</div>
            <div style="font-size:14px;color:#64748b;">Use the sidebar to log in with your staff credentials.</div>
            <div style="margin-top:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;
                        padding:14px;display:inline-block;font-size:13px;color:#64748b;">
                Demo logins (select your hospital at login):<br>
                <code>admin / staff123</code><br>
                <code>nurse1 / nurse456</code><br>
                <code>reception / rec789</code><br>
                <code>manager / mgr123</code>
            </div>
        </div>""", unsafe_allow_html=True)
        return

    hospital  = _my_hospital()
    staff_name = _my_name()
    beds      = st.session_state.beds[hospital]
    hosp_info = HOSPITALS.get(hospital, {})

    st.markdown('<span class="role-badge badge-staff">🧑‍💼 Staff Dashboard</span>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="page-header">
        <p class="page-title">Operations — {hospital}</p>
        <p class="page-sub">
            🔒 Logged in as <strong>{staff_name}</strong> &nbsp;·&nbsp;
            {hosp_info.get('specialty','')} &nbsp;·&nbsp;
            📍 {hosp_info.get('address','')}
        </p>
    </div>""", unsafe_allow_html=True)

    # Quick bed overview banner
    avail = beds["available"]
    total = beds["total"]
    color = bed_status_color(hospital)
    st.markdown(f"""
    <div style="background:{color}12;border:1px solid {color}44;border-radius:12px;
                padding:14px 20px;margin-bottom:24px;
                display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:10px;">
        <div style="display:flex;align-items:center;gap:12px;">
            <div style="width:12px;height:12px;background:{color};border-radius:50%;"></div>
            <span style="font-weight:700;color:{color};font-size:16px;">{avail} beds available</span>
            <span style="color:#64748b;font-size:13px;">out of {total} total</span>
        </div>
        <span style="color:#64748b;font-size:13px;">
            📞 {hosp_info.get('phone','')}
        </span>
    </div>""", unsafe_allow_html=True)

    # Tabs
    tab1, tab2, tab3 = st.tabs(["🛏️  Bed Management", "🚨  Emergency Admit", "📋  Patient Records"])

    with tab1:
        _tab_beds(hospital)

    with tab2:
        _tab_emergency(hospital)

    with tab3:
        _tab_patients(hospital)
