"""
doctor_ui.py — Doctor dashboard.
Each doctor is locked to their assigned hospital (from DOCTOR_CREDS).
"""

import streamlit as st
import time
from config import (
    DOCTOR_CREDS, get_queue, timestamp,
    bed_status_color,
)


# ─────────────────────────────────────────────────────────────
# HELPERS
# ─────────────────────────────────────────────────────────────
def _my_hospital() -> str:
    return st.session_state.doc_hospital

def _my_name() -> str:
    return DOCTOR_CREDS[st.session_state.doc_username]["name"]


# ─────────────────────────────────────────────────────────────
# CURRENT PATIENT CARD
# ─────────────────────────────────────────────────────────────
def _current_card(patient: dict, hospital: str):
    st.markdown(f"""
    <div class="current-card">
        <div style="font-size:11px;opacity:.75;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:10px;
                    display:flex;align-items:center;gap:8px;">
            <span style="width:8px;height:8px;background:#fff;border-radius:50%;display:inline-block;
                         animation:pulse 1.5s infinite;opacity:.8;"></span>
            NOW CONSULTING
        </div>
        <div style="font-size:28px;font-weight:800;margin-bottom:4px;">{patient['name']}</div>
        <div style="font-size:13px;opacity:.85;margin-bottom:18px;">
            📞 {patient['phone']} &nbsp;·&nbsp; Token #{patient['token']}
            &nbsp;·&nbsp; {patient.get('age','?')} yrs, {patient.get('gender','—')}
        </div>
        <div style="background:rgba(255,255,255,.18);border-radius:10px;padding:14px;margin-bottom:14px;">
            <div style="font-size:10px;opacity:.75;text-transform:uppercase;letter-spacing:1px;margin-bottom:4px;">
                Chief Complaint
            </div>
            <div style="font-size:16px;font-weight:700;">{patient['complaint']}</div>
            {f'<div style="font-size:13px;opacity:.8;margin-top:6px;">{patient["notes"]}</div>' if patient.get("notes") else ""}
        </div>
        <div style="font-size:12px;opacity:.7;">⏰ Registered at {patient.get('registered_at','—')}</div>
    </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# QUEUE LIST
# ─────────────────────────────────────────────────────────────
def _queue_list(queue: list, current_token: int):
    for i, p in enumerate(queue):
        if p["token"] == current_token:
            continue  # already shown in left panel

        wait = i * 5
        st.markdown(f"""
        <div class="q-item">
            <div style="display:flex;justify-content:space-between;align-items:flex-start;gap:10px;">
                <div style="flex:1;">
                    <div style="font-size:11px;color:#94a3b8;font-weight:600;margin-bottom:2px;">
                        #{i+1} &nbsp;·&nbsp; Token {p['token']}
                    </div>
                    <div style="font-size:16px;font-weight:700;color:#0f172a;">{p['name']}</div>
                    <div style="font-size:13px;color:#6366f1;margin-top:2px;">{p['complaint']}</div>
                    {f'<div style="font-size:12px;color:#94a3b8;margin-top:3px;">{p["notes"][:70]}…</div>' if p.get("notes") else ""}
                </div>
                <div style="text-align:right;flex-shrink:0;">
                    <div style="font-size:11px;color:#94a3b8;">Est. wait</div>
                    <div style="font-size:18px;font-weight:700;color:#d97706;">~{wait}m</div>
                    <div style="font-size:11px;color:#94a3b8;margin-top:2px;">📞 {p['phone']}</div>
                    <div style="font-size:11px;color:#94a3b8;">{p.get('age','?')}y · {p.get('gender','—')}</div>
                </div>
            </div>
        </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# MAIN RENDER
# ─────────────────────────────────────────────────────────────
def render():
    # ── Auth gate ──
    if not st.session_state.doc_logged_in:
        st.markdown("""
        <div style="text-align:center;padding:80px 20px;">
            <div style="font-size:60px;margin-bottom:16px;">🔐</div>
            <div style="font-size:22px;font-weight:700;color:#0f172a;margin-bottom:8px;">Doctor Login Required</div>
            <div style="font-size:14px;color:#64748b;">Use the sidebar to log in with your doctor credentials.</div>
            <div style="margin-top:16px;background:#f8fafc;border:1px solid #e2e8f0;border-radius:10px;
                        padding:14px;display:inline-block;font-size:13px;color:#64748b;">
                Demo logins (select your hospital at login):<br>
                <code>dr.sharma / doc123</code><br>
                <code>dr.patel / doc456</code><br>
                <code>dr.mehta / med789</code><br>
                <code>dr.khan / doc321</code>
            </div>
        </div>""", unsafe_allow_html=True)
        return

    hospital = _my_hospital()
    doc_name = _my_name()
    queue    = get_queue(hospital)
    beds     = st.session_state.beds[hospital]

    st.markdown('<span class="role-badge badge-doctor">👨‍⚕️ Doctor Dashboard</span>', unsafe_allow_html=True)
    st.markdown(f"""
    <div class="page-header">
        <p class="page-title">Welcome, {doc_name}</p>
        <p class="page-sub">🔒 {hospital} &nbsp;·&nbsp; Your assigned hospital</p>
    </div>""", unsafe_allow_html=True)

    # ── Top stats row ──
    c1, c2, c3, c4 = st.columns(4)
    done_today = len([p for p in st.session_state.patients
                      if p["hospital"] == hospital and p["status"] in ("done", "admitted")])
    admitted_now = len([p for p in st.session_state.patients
                        if p["hospital"] == hospital and p["status"] == "admitted"])
    for col, label, val, color in [
        (c1, "In Queue",        len(queue),         "#6366f1"),
        (c2, "Seen Today",      done_today,          "#16a34a"),
        (c3, "Admitted",        admitted_now,        "#0ea5e9"),
        (c4, "Beds Available",  beds["available"],   bed_status_color(hospital)),
    ]:
        with col:
            st.markdown(f"""
            <div class="stat-card">
                <div class="stat-num" style="color:{color};">{val}</div>
                <div class="stat-label">{label}</div>
            </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)

    # ── Empty queue state ──
    if not queue:
        st.markdown("""
        <div style="text-align:center;padding:60px 20px;background:#f8fafc;
                    border-radius:16px;border:1px dashed #e2e8f0;margin-top:10px;">
            <div style="font-size:48px;margin-bottom:12px;">🎉</div>
            <div style="font-size:18px;font-weight:600;color:#374151;">Queue is empty</div>
            <div style="font-size:14px;color:#94a3b8;margin-top:6px;">All patients have been seen. Great work!</div>
        </div>""", unsafe_allow_html=True)
        return

    # ── Split layout ──
    left_col, right_col = st.columns([2, 3])

    with left_col:
        current = queue[0]
        st.markdown("#### 🟢 Current Patient")
        _current_card(current, hospital)

        # Prescription
        st.markdown("##### 📝 Prescription / Notes")
        presc = st.text_area(
            label="Prescription",
            placeholder="Diagnosis, medicines, follow-up instructions…",
            height=130,
            key=f"presc_{current['token']}",
            label_visibility="collapsed",
        )

        btn1, btn2 = st.columns(2)
        with btn1:
            if st.button("✅ Next Patient", use_container_width=True, type="primary"):
                for p in st.session_state.patients:
                    if p["token"] == current["token"]:
                        p["status"]       = "done"
                        p["prescription"] = presc
                        p["completed_at"] = timestamp()
                        break
                st.toast(f"✅ {current['name']} marked as done", icon="✅")
                time.sleep(0.4)
                st.rerun()

        with btn2:
            avail = beds["available"]
            if avail > 0:
                if st.button("🏥 Admit", use_container_width=True):
                    for p in st.session_state.patients:
                        if p["token"] == current["token"]:
                            p["status"]      = "admitted"
                            p["admitted_at"] = timestamp()
                            break
                    st.session_state.beds[hospital]["available"] -= 1
                    st.toast(f"🏥 {current['name']} admitted", icon="🏥")
                    time.sleep(0.4)
                    st.rerun()
            else:
                st.markdown("""
                <div style="background:#fef2f2;border:1px solid #fecaca;border-radius:8px;
                            padding:8px;text-align:center;font-size:12px;color:#dc2626;font-weight:600;">
                    No beds! 🚫
                </div>""", unsafe_allow_html=True)

        # Skip patient
        with st.expander("⚠️ Skip / Re-queue Patient"):
            st.caption("Move this patient to the end of the queue (e.g. not present).")
            if st.button("Skip to End", use_container_width=True):
                for p in st.session_state.patients:
                    if p["token"] == current["token"]:
                        st.session_state.patients.remove(p)
                        st.session_state.patients.append(p)
                        break
                st.toast("Patient moved to end of queue.")
                time.sleep(0.3)
                st.rerun()

    with right_col:
        st.markdown(f"#### 📋 Waiting Queue — {len(queue)} patient(s)")
        _queue_list(queue, current["token"])

        # Completed today section
        done_list = [p for p in st.session_state.patients
                     if p["hospital"] == hospital and p["status"] in ("done","admitted")]
        if done_list:
            with st.expander(f"📂 Completed Today ({len(done_list)})", expanded=False):
                for p in done_list:
                    icon = "✅" if p["status"] == "done" else "🏥"
                    st.markdown(f"""
                    <div style="background:#f8fafc;border:1px solid #e2e8f0;border-radius:8px;
                                padding:10px 14px;margin-bottom:6px;
                                display:flex;justify-content:space-between;align-items:center;">
                        <div>
                            <span style="font-weight:600;color:#0f172a;">{icon} {p['name']}</span>
                            <span style="font-size:12px;color:#94a3b8;margin-left:8px;">#{p['token']}</span>
                        </div>
                        <span style="font-size:12px;color:#64748b;">{p['complaint']}</span>
                    </div>""", unsafe_allow_html=True)
