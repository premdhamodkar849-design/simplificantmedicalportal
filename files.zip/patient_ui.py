"""
patient_ui.py — Full patient portal with map-based hospital selection,
registration, token issuance, and live queue tracking.
"""

import streamlit as st
import time
from config import (
    HOSPITALS, COMPLAINTS,
    next_token, get_queue, get_patient_by_token,
    queue_position, bed_status_color, timestamp,
)

# ── try to import folium; graceful fallback ──────────────────
try:
    import folium
    from streamlit_folium import st_folium
    HAS_FOLIUM = True
except ImportError:
    HAS_FOLIUM = False


# ─────────────────────────────────────────────────────────────
# STEP INDICATOR
# ─────────────────────────────────────────────────────────────
def _stepper(current_step: str):
    steps = [
        ("select_hospital", "Find Hospital"),
        ("register",        "Register"),
        ("token",           "Token"),
        ("track",           "Track"),
    ]
    idx_map = {s[0]: i for i, s in enumerate(steps)}
    cur = idx_map.get(current_step, 0)

    cols = st.columns(len(steps))
    for i, (key, label) in enumerate(steps):
        with cols[i]:
            if i < cur:    cls, icon = "sd-done",   "✓"
            elif i == cur: cls, icon = "sd-active",  str(i+1)
            else:          cls, icon = "sd-todo",    str(i+1)
            st.markdown(f"""
            <div style="text-align:center;">
                <div class="step-dot {cls}">{icon}</div>
                <div style="font-size:11px;color:#64748b;font-weight:500;">{label}</div>
            </div>""", unsafe_allow_html=True)
    st.markdown("<hr>", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# STEP 1 — Hospital Selection with Map
# ─────────────────────────────────────────────────────────────
def _step_select_hospital():
    st.markdown("""
    <div class="page-header">
        <p class="page-title">🏥 Find a Hospital Near You</p>
        <p class="page-sub">Search on the map or pick from the list below</p>
    </div>""", unsafe_allow_html=True)

    # ── Search bar ──
    search = st.text_input(
        "🔍 Search hospital by name or area",
        placeholder="e.g. Apollo, Baner, General…",
        key="pat_search"
    )

    # ── MAP ──────────────────────────────────────────────────
    if HAS_FOLIUM:
        center_lat = sum(h["lat"] for h in HOSPITALS.values()) / len(HOSPITALS)
        center_lng = sum(h["lng"] for h in HOSPITALS.values()) / len(HOSPITALS)

        m = folium.Map(
            location=[center_lat, center_lng],
            zoom_start=12,
            tiles="CartoDB positron",
        )

        for name, info in HOSPITALS.items():
            beds   = st.session_state.beds[name]
            avail  = beds["available"]
            total  = beds["total"]
            queue  = len(get_queue(name))
            color  = "#22c55e" if avail > total * 0.3 else ("#f59e0b" if avail > 0 else "#ef4444")
            icon_c = "green"   if avail > total * 0.3 else ("orange"  if avail > 0 else "red")

            popup_html = f"""
            <div style="font-family:Inter,sans-serif;min-width:200px;padding:4px;">
                <div style="font-size:15px;font-weight:700;color:#0f172a;margin-bottom:6px;">{name}</div>
                <div style="font-size:12px;color:#64748b;margin-bottom:4px;">📍 {info['address']}</div>
                <div style="font-size:12px;color:#64748b;margin-bottom:8px;">🔬 {info['specialty']}</div>
                <div style="display:flex;gap:8px;flex-wrap:wrap;">
                    <span style="background:{color}22;color:{color};padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
                        🛏 {avail}/{total} beds
                    </span>
                    <span style="background:#6366f111;color:#6366f1;padding:2px 8px;border-radius:999px;font-size:11px;font-weight:600;">
                        👥 {queue} in queue
                    </span>
                </div>
            </div>
            """
            folium.Marker(
                location=[info["lat"], info["lng"]],
                popup=folium.Popup(popup_html, max_width=250),
                tooltip=f"🏥 {name}",
                icon=folium.Icon(color=icon_c, icon="plus-sign", prefix="glyphicon"),
            ).add_to(m)

        st.markdown("**Interactive Map** — click a pin for details:")
        st_folium(m, height=360, use_container_width=True)
        st.markdown("<br>", unsafe_allow_html=True)
    else:
        st.info("💡 Install `folium` and `streamlit-folium` for an interactive map: `pip install folium streamlit-folium`")

    # ── Hospital cards ────────────────────────────────────────
    st.markdown("**Select your hospital:**")
    filtered = {
        name: info for name, info in HOSPITALS.items()
        if search.lower() in name.lower() or search.lower() in info["address"].lower()
    } if search.strip() else HOSPITALS

    if not filtered:
        st.warning("No hospitals match your search.")
        return

    for name, info in filtered.items():
        beds  = st.session_state.beds[name]
        avail = beds["available"]
        total = beds["total"]
        queue = len(get_queue(name))
        color = bed_status_color(name)
        pct   = int(avail / total * 100) if total else 0

        col_card, col_btn = st.columns([5, 1])
        with col_card:
            st.markdown(f"""
            <div class="hosp-card">
                <div style="display:flex;justify-content:space-between;align-items:flex-start;flex-wrap:wrap;gap:8px;">
                    <div>
                        <div style="font-size:16px;font-weight:700;color:#0f172a;">{name}</div>
                        <div style="font-size:12px;color:#94a3b8;margin-top:2px;">
                            📍 {info['address']} &nbsp;·&nbsp; 🔬 {info['specialty']}
                        </div>
                    </div>
                    <div style="text-align:right;font-size:12px;color:#64748b;">📞 {info['phone']}</div>
                </div>
                <div style="display:flex;gap:8px;margin-top:12px;align-items:center;flex-wrap:wrap;">
                    <span style="background:{color}15;color:{color};padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;">
                        🛏 {avail}/{total} beds
                    </span>
                    <span style="background:#6366f111;color:#6366f1;padding:3px 10px;border-radius:999px;font-size:12px;font-weight:600;">
                        👥 {queue} in queue
                    </span>
                    <div style="flex:1;min-width:80px;">
                        <div style="height:5px;background:#e2e8f0;border-radius:999px;overflow:hidden;">
                            <div style="width:{pct}%;height:5px;background:{color};border-radius:999px;"></div>
                        </div>
                    </div>
                    <span style="font-size:11px;color:#94a3b8;">{pct}% available</span>
                </div>
            </div>""", unsafe_allow_html=True)

        with col_btn:
            st.markdown("<div style='height:24px'></div>", unsafe_allow_html=True)
            if avail > 0:
                if st.button("Select →", key=f"hsel_{name}", use_container_width=True, type="primary"):
                    st.session_state.pat_hospital = name
                    st.session_state.pat_step = "register"
                    st.rerun()
            else:
                st.markdown("""
                <div style="background:#fef2f2;color:#dc2626;text-align:center;
                            border-radius:8px;padding:6px 8px;font-size:12px;font-weight:600;">
                    Full 🚫
                </div>""", unsafe_allow_html=True)


# ─────────────────────────────────────────────────────────────
# STEP 2 — Registration Form
# ─────────────────────────────────────────────────────────────
def _step_register():
    hosp = st.session_state.pat_hospital
    st.markdown(f"""
    <div class="page-header">
        <p class="page-title">Patient Registration</p>
        <p class="page-sub">Registering at <strong>{hosp}</strong></p>
    </div>""", unsafe_allow_html=True)

    # Locked hospital notice
    st.markdown(f"""
    <div style="background:#ede9fe;border:1px solid #c4b5fd;border-radius:10px;
                padding:12px 16px;margin-bottom:20px;display:flex;align-items:center;gap:10px;">
        <span style="font-size:18px;">🔒</span>
        <span style="color:#5b21b6;font-size:14px;font-weight:600;">
            Your session is locked to <strong>{hosp}</strong> for privacy.
        </span>
    </div>""", unsafe_allow_html=True)

    with st.form("patient_reg_form", clear_on_submit=False):
        c1, c2 = st.columns(2)
        with c1:
            name   = st.text_input("Full Name *", placeholder="e.g. Rahul Sharma")
            mobile = st.text_input("Mobile Number *", placeholder="10-digit mobile", max_chars=10)
        with c2:
            age    = st.number_input("Age", min_value=0, max_value=120, value=30)
            gender = st.selectbox("Gender", ["Prefer not to say", "Male", "Female", "Other"])

        complaint = st.selectbox("Chief Complaint *", COMPLAINTS)
        notes = st.text_area(
            "Describe your symptoms (optional)",
            placeholder="Duration, severity, any medications taken…",
            height=90,
        )

        st.markdown("<div style='height:8px'></div>", unsafe_allow_html=True)
        col_b, col_s = st.columns([1, 2])
        with col_b:
            back   = st.form_submit_button("← Back")
        with col_s:
            submit = st.form_submit_button("Get My Token →", type="primary", use_container_width=True)

    if back:
        st.session_state.pat_step = "select_hospital"
        st.rerun()

    if submit:
        if not name.strip():
            st.error("Please enter your full name.")
            return
        if not mobile.strip() or not mobile.isdigit() or len(mobile) != 10:
            st.error("Please enter a valid 10-digit mobile number.")
            return

        # Duplicate check
        existing = [p for p in st.session_state.patients
                    if p["phone"] == mobile and p["hospital"] == hosp and p["status"] == "waiting"]
        if existing:
            st.warning("⚠️ This mobile is already registered here. Taking you to your tracker…")
            st.session_state.pat_token  = existing[0]["token"]
            st.session_state.pat_mobile = mobile
            st.session_state.pat_name   = existing[0]["name"]
            st.session_state.pat_step   = "track"
            time.sleep(0.8)
            st.rerun()
            return

        token = next_token()
        patient = {
            "id":            len(st.session_state.patients) + 1,
            "name":          name.strip(),
            "phone":         mobile,
            "age":           age,
            "gender":        gender,
            "complaint":     complaint,
            "notes":         notes.strip(),
            "token":         token,
            "status":        "waiting",
            "hospital":      hosp,
            "registered_at": timestamp(),
        }
        st.session_state.patients.append(patient)
        st.session_state.pat_token  = token
        st.session_state.pat_mobile = mobile
        st.session_state.pat_name   = name.strip()
        st.session_state.pat_step   = "token"
        st.rerun()


# ─────────────────────────────────────────────────────────────
# STEP 3 — Token Issued
# ─────────────────────────────────────────────────────────────
def _step_token():
    patient = get_patient_by_token(st.session_state.pat_token)
    if not patient:
        st.error("Session expired.")
        st.session_state.pat_step = "select_hospital"
        st.rerun()
        return

    pos  = queue_position(patient) or 1
    wait = pos * 5

    st.markdown("""
    <div class="page-header">
        <p class="page-title">🎉 Token Issued!</p>
        <p class="page-sub">Save this token number — you'll need it to track your position.</p>
    </div>""", unsafe_allow_html=True)

    col_token, col_info = st.columns([1, 1])
    with col_token:
        st.markdown(f"""
        <div class="token-card">
            <div class="token-label">Your Token</div>
            <div class="token-num">#{patient['token']}</div>
            <div style="margin-top:14px;font-size:15px;opacity:.9;font-weight:600;">{patient['hospital']}</div>
            <div style="margin-top:6px;font-size:12px;opacity:.7;">Registered at {patient['registered_at']}</div>
        </div>""", unsafe_allow_html=True)

    with col_info:
        st.markdown(f"""
        <div class="card" style="height:100%;box-sizing:border-box;">
            <div style="font-size:11px;color:#94a3b8;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:16px;font-weight:600;">
                Summary
            </div>
            <div style="display:flex;flex-direction:column;gap:14px;">
                <div>
                    <div style="font-size:11px;color:#94a3b8;">PATIENT</div>
                    <div style="font-weight:700;color:#0f172a;font-size:15px;">{patient['name']}</div>
                </div>
                <div>
                    <div style="font-size:11px;color:#94a3b8;">MOBILE</div>
                    <div style="font-weight:600;color:#0f172a;">{patient['phone']}</div>
                </div>
                <div>
                    <div style="font-size:11px;color:#94a3b8;">COMPLAINT</div>
                    <div style="font-weight:600;color:#6366f1;">{patient['complaint']}</div>
                </div>
                <div style="display:flex;gap:20px;">
                    <div>
                        <div style="font-size:11px;color:#94a3b8;">POSITION</div>
                        <div style="font-size:28px;font-weight:800;color:#6366f1;line-height:1.1;">#{pos}</div>
                    </div>
                    <div>
                        <div style="font-size:11px;color:#94a3b8;">EST. WAIT</div>
                        <div style="font-size:28px;font-weight:800;color:#d97706;line-height:1.1;">{wait}m</div>
                    </div>
                </div>
            </div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    st.success(f"📲 **SMS Notification (Simulated):** We'll text {patient['phone']} when you're next in line.")

    if st.button("📍 Track My Position Live →", use_container_width=True, type="primary"):
        st.session_state.pat_step = "track"
        st.rerun()


# ─────────────────────────────────────────────────────────────
# STEP 4 — Live Queue Tracker
# ─────────────────────────────────────────────────────────────
def _step_track():
    patient = get_patient_by_token(st.session_state.pat_token)
    if not patient:
        st.error("Patient not found. Please register again.")
        st.session_state.pat_step = "select_hospital"
        return

    st.markdown(f"""
    <div class="page-header">
        <p class="page-title">📍 Live Queue Tracker</p>
        <p class="page-sub">🔒 {patient['hospital']} &nbsp;·&nbsp; Token #{patient['token']}</p>
    </div>""", unsafe_allow_html=True)

    # Terminal states
    if patient["status"] == "done":
        st.success("✅ Your consultation is **complete**. Thank you for visiting!")
        st.balloons()
        if st.button("Return to Home", use_container_width=True, type="primary"):
            st.session_state.pat_step    = "select_hospital"
            st.session_state.pat_token   = None
            st.session_state.pat_hospital = None
            st.rerun()
        return

    if patient["status"] == "admitted":
        st.markdown("""
        <div style="background:#dbeafe;border:1px solid #93c5fd;border-radius:14px;
                    padding:28px;text-align:center;margin-bottom:20px;">
            <div style="font-size:40px;margin-bottom:10px;">🏥</div>
            <div style="font-size:20px;font-weight:700;color:#1e40af;">You've been admitted</div>
            <div style="font-size:14px;color:#3b82f6;margin-top:6px;">A bed has been allocated. Please follow the ward staff.</div>
        </div>""", unsafe_allow_html=True)
        if st.button("Return to Home", use_container_width=True):
            st.session_state.pat_step    = "select_hospital"
            st.session_state.pat_token   = None
            st.session_state.pat_hospital = None
            st.rerun()
        return

    # Live tracking
    pos   = queue_position(patient)
    if pos is None:
        st.info("Updating your position…")
        time.sleep(0.5)
        st.rerun()
        return

    wait  = pos * 5
    queue = get_queue(patient["hospital"])
    total_in_q = len(queue)
    progress = max(0.0, min(1.0, 1 - (pos / max(total_in_q, 1))))

    left, right = st.columns([3, 2])

    with left:
        # Status banner
        if pos == 1:
            st.success("🔔 **You're next!** Please proceed to the consultation room now.")
        elif pos <= 3:
            st.warning(f"⚡ Almost there — **{pos - 1} patient(s) before you**")
        else:
            st.info(f"👥 **{pos - 1} patient(s) ahead.** Estimated wait: **{wait} minutes**")

        st.markdown("<div style='height:6px'></div>", unsafe_allow_html=True)
        st.progress(progress)
        st.markdown(f"""
        <div style="display:flex;justify-content:space-between;font-size:11px;color:#94a3b8;margin-top:4px;">
            <span>Start</span><span>{int(progress*100)}% through queue</span><span>Your turn</span>
        </div>""", unsafe_allow_html=True)

        st.markdown("<br>**Queue Preview:**", unsafe_allow_html=True)
        for i, p in enumerate(queue[:8]):
            is_me = p["token"] == patient["token"]
            bg  = "#ede9fe" if is_me else "#f8fafc"
            bdc = "#6366f1" if is_me else "#e2e8f0"
            st.markdown(f"""
            <div style="background:{bg};border:1px solid {bdc};border-radius:8px;
                        padding:10px 14px;margin-bottom:6px;
                        display:flex;justify-content:space-between;align-items:center;">
                <span style="font-weight:{'700' if is_me else '400'};
                             color:{'#5b21b6' if is_me else '#374151'};font-size:14px;">
                    {'👉 YOU — ' if is_me else f'{i+1}.  '}Token #{p['token']} · {p['name']}
                </span>
                <span style="font-size:12px;color:#94a3b8;">{'🟣' if is_me else p['complaint'][:20]}</span>
            </div>""", unsafe_allow_html=True)

        if total_in_q > 8:
            st.markdown(f"<div style='text-align:center;color:#94a3b8;font-size:12px;margin-top:4px;'>+{total_in_q - 8} more patients</div>", unsafe_allow_html=True)

    with right:
        st.markdown(f"""
        <div style="background:linear-gradient(135deg,#6366f1,#8b5cf6);
                    border-radius:16px;padding:24px;color:white;text-align:center;margin-bottom:14px;">
            <div style="font-size:11px;opacity:.75;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px;">Queue Position</div>
            <div style="font-size:80px;font-weight:900;line-height:1;">#{pos}</div>
            <div style="font-size:12px;opacity:.7;margin-top:4px;">of {total_in_q} waiting</div>
        </div>
        <div style="background:#fff7ed;border:1px solid #fed7aa;border-radius:14px;
                    padding:20px;text-align:center;margin-bottom:14px;">
            <div style="font-size:11px;color:#c2410c;text-transform:uppercase;letter-spacing:1.5px;margin-bottom:6px;">Est. Wait Time</div>
            <div style="font-size:52px;font-weight:800;color:#ea580c;line-height:1;">{wait}</div>
            <div style="font-size:12px;color:#c2410c;margin-top:2px;">minutes</div>
        </div>
        <div style="background:#f0fdf4;border:1px solid #bbf7d0;border-radius:12px;
                    padding:16px;text-align:center;">
            <div style="font-size:12px;color:#166534;font-weight:600;margin-bottom:4px;">📲 SMS Alert Active</div>
            <div style="font-size:12px;color:#15803d;">Will notify<br><strong>{patient['phone']}</strong></div>
        </div>""", unsafe_allow_html=True)

    st.markdown("<br>", unsafe_allow_html=True)
    col_r, col_h = st.columns(2)
    with col_r:
        if st.button("🔄 Refresh", use_container_width=True):
            st.rerun()
    with col_h:
        if st.button("🏠 Home", use_container_width=True):
            st.session_state.pat_step    = "select_hospital"
            st.session_state.pat_token   = None
            st.session_state.pat_hospital = None
            st.rerun()


# ─────────────────────────────────────────────────────────────
# MAIN ENTRY
# ─────────────────────────────────────────────────────────────
def render():
    st.markdown('<span class="role-badge badge-patient">👤 Patient Portal</span>', unsafe_allow_html=True)
    _stepper(st.session_state.pat_step)

    step = st.session_state.pat_step
    if step == "select_hospital": _step_select_hospital()
    elif step == "register":      _step_register()
    elif step == "token":         _step_token()
    elif step == "track":         _step_track()
