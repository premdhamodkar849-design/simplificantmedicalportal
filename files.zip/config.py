"""
config.py — Shared constants, credentials, hospital data, and session state bootstrap.
All modules import from here to keep a single source of truth.
"""

# ─────────────────────────────────────────────────────────────
# HOSPITAL MASTER DATA
# ─────────────────────────────────────────────────────────────
HOSPITALS = {
    "City General Hospital": {
        "address": "MG Road, Pune, Maharashtra 411001",
        "lat": 18.5204,
        "lng": 72.8567,
        "specialty": "Multi-specialty",
        "phone": "+91-20-2612-3456",
        "color": "#6366f1",
    },
    "Apollo MediCare": {
        "address": "Baner Road, Pune, Maharashtra 411045",
        "lat": 18.5590,
        "lng": 73.7868,
        "specialty": "Super-specialty",
        "phone": "+91-20-6620-0000",
        "color": "#0ea5e9",
    },
    "Sunrise Health Centre": {
        "address": "Kothrud, Pune, Maharashtra 411038",
        "lat": 18.5074,
        "lng": 73.8077,
        "specialty": "General",
        "phone": "+91-20-2544-1234",
        "color": "#f59e0b",
    },
    "St. Mary's Hospital": {
        "address": "Camp Area, Pune, Maharashtra 411001",
        "lat": 18.5167,
        "lng": 73.8706,
        "specialty": "Multi-specialty",
        "phone": "+91-20-2612-7890",
        "color": "#10b981",
    },
}

# ─────────────────────────────────────────────────────────────
# CREDENTIALS  (username → {password, hospital})
# ─────────────────────────────────────────────────────────────
DOCTOR_CREDS = {
    "dr.sharma": {"password": "doc123", "name": "Dr. Priya Sharma"},
    "dr.patel":  {"password": "doc456", "name": "Dr. Rohan Patel"},
    "dr.mehta":  {"password": "med789", "name": "Dr. Anita Mehta"},
    "dr.khan":   {"password": "doc321", "name": "Dr. Salman Khan"},
}

STAFF_CREDS = {
    "admin":      {"password": "staff123", "name": "Admin"},
    "nurse1":     {"password": "nurse456", "name": "Nurse Priya"},
    "reception":  {"password": "rec789",   "name": "Reception"},
    "manager":    {"password": "mgr123",   "name": "Manager"},
}

# ─────────────────────────────────────────────────────────────
# COMPLAINT OPTIONS
# ─────────────────────────────────────────────────────────────
COMPLAINTS = [
    "Fever / Cold / Cough",
    "Chest Pain",
    "Abdominal Pain",
    "Head Injury / Trauma",
    "Fracture / Orthopaedic",
    "Eye / ENT Issue",
    "Skin Problem / Rash",
    "Gynaecology",
    "Paediatric Issue",
    "Dental Pain",
    "Mental Health",
    "Neurological Issue",
    "Diabetes / BP Check",
    "Other",
]

# ─────────────────────────────────────────────────────────────
# SESSION STATE BOOTSTRAP
# ─────────────────────────────────────────────────────────────
def init_state():
    defaults = {
        # patients list[dict]
        "patients": [],
        "token_counter": 1000,

        # beds  {hospital: {total, available}}
        "beds": {
            "City General Hospital": {"total": 20, "available": 13},
            "Apollo MediCare":        {"total": 30, "available":  4},
            "Sunrise Health Centre":  {"total": 15, "available": 15},
            "St. Mary's Hospital":    {"total": 25, "available":  9},
        },

        # role navigation
        "role": "Patient",

        # patient session
        "pat_step": "select_hospital",
        "pat_hospital": None,
        "pat_token": None,
        "pat_mobile": None,
        "pat_name": None,

        # auth
        "doc_logged_in":  False,
        "doc_username":   None,
        "doc_hospital":   None,
        "staff_logged_in": False,
        "staff_username":  None,
        "staff_hospital":  None,
    }
    import streamlit as st
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v


# ─────────────────────────────────────────────────────────────
# SHARED HELPERS
# ─────────────────────────────────────────────────────────────
def next_token():
    import streamlit as st
    st.session_state.token_counter += 1
    return st.session_state.token_counter

def get_queue(hospital):
    import streamlit as st
    return [p for p in st.session_state.patients
            if p["hospital"] == hospital and p["status"] == "waiting"]

def get_patient_by_token(token):
    import streamlit as st
    for p in st.session_state.patients:
        if p["token"] == token:
            return p
    return None

def queue_position(patient):
    q = get_queue(patient["hospital"])
    for i, p in enumerate(q):
        if p["token"] == patient["token"]:
            return i + 1
    return None

def bed_status_color(hospital):
    import streamlit as st
    avail = st.session_state.beds[hospital]["available"]
    total = st.session_state.beds[hospital]["total"]
    pct = avail / total if total else 0
    if pct > 0.3:  return "#16a34a"
    if pct > 0.1:  return "#d97706"
    return "#ef4444"

def timestamp():
    from datetime import datetime
    return datetime.now().strftime("%H:%M")
